export const serverAddress = 'http://localhost:3001/'; 
export const SIGNUP = 'api/auth/signup';
export const VERIFY_OTP = 'api/auth/verifyOTP';
export const SIGNIN = 'api/auth/signin';
export const AUTH = 'api/auth';
export const ADDCATEGORY = 'api/category';
export const ADDSTOREOWNER = 'api/admin/addStoreOwner';

